#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"  // for MAXARG

// xargs: run a command for each line of input.
// The command (and its initial arguments) are passed as command-line arguments.
// For each line read from standard input, the program appends the line as one more argument,
// and executes the command with that argument list.

int
main(int argc, char *argv[])
{
    // Make sure a command is provided.
    if(argc < 2){
        fprintf(2, "Usage: xargs <command> [args...]\n");
        exit(1);
    }

    // Build an initial argv array for the command.
    // We'll put the provided command and its arguments in cmd.
    int n = argc - 1;  // number of given arguments
    char *cmd[MAXARG];
    for(int i = 0; i < n; i++){
        cmd[i] = argv[i+1];
    }
    // Reserve slot n for the extra argument (the line read from input),
    // and then terminate with a NULL pointer.
    // (Thus, the executed command will see argv[0..n] and then a null.)

    char buf[512];  // buffer to store a line from standard input
    while(1){
        int pos = 0;
        int r;

        // Read the first character.
        r = read(0, &buf[pos], 1);
        if(r == 0)  // EOF reached
            break;

        // Read characters until newline or buffer is full.
        while(1){
            if(buf[pos] == '\n')
                break;
            pos++;
            if(pos >= sizeof(buf) - 1)
                break;
            r = read(0, &buf[pos], 1);
            if(r == 0)
                break;
        }
        buf[pos] = 0;  // null-terminate the string

        // Allocate space to hold a copy of this line.
        int len = strlen(buf);
        char *line = malloc(len+1);
        if(line == 0){
            fprintf(2, "xargs: out of memory\n");
            exit(1);
        }
        strcpy(line, buf);
        // Append the line as the extra argument.
        cmd[n] = line;
        cmd[n+1] = 0;  // terminate the argument list

        // Fork and exec the command.
        int pid = fork();
        if(pid < 0){
            fprintf(2, "xargs: fork failed\n");
            exit(1);
        }
        if(pid == 0){
            // In the child, execute the command.
            exec(cmd[0], cmd);
            // If exec returns, an error occurred.
            fprintf(2, "xargs: exec %s failed\n", cmd[0]);
            exit(1);
        }
        // In the parent, wait for the child.
        wait(0);
        free(line);
    }
    exit(0);
}
