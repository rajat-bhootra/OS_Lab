#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Prototype for the sctime system call.
// This system call should return the elapsed time in seconds
// since the most recent system call.


int
main(void)
{
    int elapsed = sctime();
    printf("Time elapsed since last system call: %d sec\n", elapsed);
    exit(0);
}
