#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(void)
{
  int count = syscount();  // call the new system call
  printf("Number of system calls: %d\n", count);
  return 0;
}
