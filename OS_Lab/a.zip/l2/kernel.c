#define UART 0x10000000UL
#include <stdint.h>
// volatile unsigned char*uart = (volatile char *)UART;
void pt(char * name){
    while (*name){
        *(volatile char *)UART = *name;
        name++;
    } 
}

int main(void){
    pt("Dosa idli sambhar chutney chutney");

    while (1){
        asm volatile("wfi");
    }
    return 0;
}