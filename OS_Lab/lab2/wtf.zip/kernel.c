#define UART 0x10000000

void mainv(){
    char *name = "bhupendra jogi";
    while (*name){
        *(volatile char *)UART = *name;
        name++;
    }
}

void traphdd(){
}